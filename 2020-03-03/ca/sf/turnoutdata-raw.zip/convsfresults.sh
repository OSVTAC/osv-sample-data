#!/bin/sh
# This script calls the results converter
# It can be modified to change the path or add options
convsfresults.py -v -P $*

